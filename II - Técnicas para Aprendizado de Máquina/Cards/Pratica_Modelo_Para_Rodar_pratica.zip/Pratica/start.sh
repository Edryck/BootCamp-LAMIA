#!/bin/bash

# Inicia todos os containers
docker-compose up -d --build
