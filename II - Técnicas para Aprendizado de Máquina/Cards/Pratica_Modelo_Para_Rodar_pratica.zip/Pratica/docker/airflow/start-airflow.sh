#!/usr/bin/env bash

cd $AIRFLOW_HOME

# Inicializa o banco de dados
airflow db migrate

# Cria usuário administrador
airflow users create \
    --username admin \
    --password admin \
    --firstname Admin \
    --lastname User \
    --role Admin \
    --email admin@example.com 2>/dev/null || true

# Inicia o scheduler em background
airflow scheduler &> /dev/null &

# Inicia o webserver em foreground
exec airflow webserver
